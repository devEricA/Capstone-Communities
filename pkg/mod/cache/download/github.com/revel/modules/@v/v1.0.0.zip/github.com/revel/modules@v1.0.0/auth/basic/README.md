modules/basic/auth
===============

Basic user/auth module

This should be modeled after [flask-security](https://github.com/mattupstate/flask-security)
